import { Customer } from "./customer.modal";
export interface AppState {
  readonly customers: Customer[];
}
